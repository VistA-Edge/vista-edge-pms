VistA-Edge Practice Management System beta release 0.9

9 December 2010


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; 
; Copyright � 2009 Edgeware Technologies (India) Pvt Ltd
 
; This source code contains the intellectual property 
; of its copyright holder(s), and is made available 
; under a license. If you do not know the terms of 
; the license, please stop and do not read further. 
; 
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;



Overview:
--------
VistA-Edge Practice Management System integrated with VistA, the electronic health information system developed by the US department of Veterans Affairs(VA), released under the Affero GNU Public License.

This software can also be used independent of VistA as a standalone Practice management System.


Installation Steps:
-------------------


1. To install Practice management System use the "VistA Edge PMS installation manual.pdf"









